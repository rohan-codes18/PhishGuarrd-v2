// ==========================
// PhishGuard v2
// URL Scanner
// ==========================

const scanBtn = document.getElementById("scanBtn");
const urlInput = document.getElementById("urlInput");
const resultBox = document.getElementById("resultBox");

scanBtn.addEventListener("click", scanWebsite);

function scanWebsite() {

    const url = urlInput.value.trim();

    if (url === "") {

        resultBox.innerHTML = `
            <div class="result-icon">
                <i class="fa-solid fa-circle-exclamation"></i>
            </div>

            <h3>Please Enter a URL</h3>

            <p>Enter a valid website address.</p>
        `;

        return;
    }

    scanBtn.innerHTML = "Scanning...";
    scanBtn.disabled = true;

    setTimeout(() => {

        analyzeURL(url);

        scanBtn.innerHTML = "Scan Now";
        scanBtn.disabled = false;

    }, 2000);

}

function analyzeURL(url){

    let status = "";
    let color = "";
    let score = 0;

    const lower = url.toLowerCase();

    if(
        lower.includes("login") ||
        lower.includes("verify") ||
        lower.includes("update") ||
        lower.includes("secure") ||
        lower.includes("@") ||
        lower.includes("free")
    ){

        status = "⚠ Suspicious";
        color = "#ff9800";
        score = 62;

    }

    else if(
        lower.includes("paypal-security") ||
        lower.includes("bank") ||
        lower.includes("gift") ||
        lower.includes("bitcoin") ||
        lower.includes("wallet")
    ){

        status = "🚨 High Risk";
        color = "#ff1744";
        score = 91;

    }

    else{

        status = "✅ Safe";
        color = "#00e676";
        score = 12;

    }

    showResult(url,status,color,score);

}

// ==========================
// Show Scan Result
// ==========================

function showResult(url, status, color, score) {

    const today = new Date();

    const scanTime = today.toLocaleString();

    resultBox.innerHTML = `

        <div class="result-icon">

            <i class="fa-solid fa-shield-virus"
               style="color:${color};font-size:65px;"></i>

        </div>

        <h2 style="color:${color};margin-top:15px;">
            ${status}
        </h2>

        <br>

        <p><strong>Website:</strong></p>

        <p style="word-break:break-word;">
            ${url}
        </p>

        <br>

        <p>
            <strong>Risk Score:</strong>
            ${score}/100
        </p>

        <br>

        <div style="
            width:100%;
            height:12px;
            background:#1d2c40;
            border-radius:20px;
            overflow:hidden;
        ">

            <div style="
                width:${score}%;
                height:100%;
                background:${color};
                transition:1s;
            "></div>

        </div>

        <br>

        <p>
            <strong>Scan Time:</strong><br>
            ${scanTime}
        </p>

    `;

}

// ==========================
// Scan with Enter Key
// ==========================

urlInput.addEventListener("keypress", function(event){

    if(event.key === "Enter"){

        event.preventDefault();

        scanWebsite();

    }

});

// ==========================
// Auto Focus
// ==========================

window.onload = function(){

    urlInput.focus();

};

